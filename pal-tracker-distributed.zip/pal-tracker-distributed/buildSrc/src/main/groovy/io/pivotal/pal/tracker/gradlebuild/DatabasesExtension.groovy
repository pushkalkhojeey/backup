package io.pivotal.pal.tracker.gradlebuild

class DatabasesExtension {
    String devDatabase
    String testDatabase
    String cfDatabase
    String cfApp
}
